import InterfaceGrafica.Janela;

public class Jogo {

	public static void main(String[] args) {
		
		Janela janela = new Janela();

	}

}
