
public class Sala {

	

}
